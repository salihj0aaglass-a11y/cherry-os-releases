#!/bin/bash
# One command does everything: bash start.sh
cd "$(dirname "$0")" || exit 1

# remove the boot service from install.sh if it is there (it cannot work under Windows)
if [ -f /etc/systemd/system/cherry.service ] && grep -qi microsoft /proc/version; then
    sudo systemctl disable --now cherry >/dev/null 2>&1
    sudo rm -f /etc/systemd/system/cherry.service
    sudo systemctl daemon-reload >/dev/null 2>&1
fi

# install what is missing, once
if ! command -v Xephyr >/dev/null || ! command -v openbox >/dev/null || \
   ! command -v xprop >/dev/null || [ ! -f /usr/include/SDL2/SDL.h ]; then
    rm -f .setup-done                  # next start shows a window again
    if [ "$(id -u)" != 0 ] && ! sudo -n true 2>/dev/null && [ ! -t 0 ]; then
        exit 1                         # needs a password and nobody can type it
    fi
    echo "Installing what Cherry OS needs (one time only)..."
    if [ "$(id -u)" = 0 ]; then SUDO=; else SUDO=sudo; fi
    $SUDO apt-get update
    $SUDO env DEBIAN_FRONTEND=noninteractive apt-get install -y xserver-xephyr openbox x11-utils libsdl2-dev libssl-dev pkg-config make gcc qt5ct
fi

[ -f cherry.new ] && mv -f cherry.new cherry
# build only when there is nothing to run yet: updates arrive ready-built
if [ ! -x cherry ] && [ ! -f cherry.new ]; then
    make -s CFLAGS="-O2 -w" 2>/dev/null || make || exit 1
fi
chmod +x cherry cherry-session 2>/dev/null
touch .setup-done                      # from now on the Windows launcher starts it quietly
[ "$1" = "--setup-only" ] && exit 0    # Cherry OS Setup builds it, then opens it its own way

if command -v Xephyr >/dev/null && command -v openbox >/dev/null; then
    exec sh ./cherry-session
else
    while :; do                        # same as before, without matching title bars
        [ -f cherry.new ] && mv -f cherry.new cherry
        ./cherry --assets assets
        [ $? -eq 42 ] || break
    done
fi
