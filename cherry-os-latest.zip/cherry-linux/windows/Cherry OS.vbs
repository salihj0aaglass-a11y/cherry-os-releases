' Starts Cherry OS with no terminal window.
' The first time (while it sets itself up) a window is shown so you can see progress.
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
here = fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName))

' D:\Cherry\cherry-18  ->  /mnt/d/Cherry/cherry-18
linux = "/mnt/" & LCase(Left(here, 1)) & Replace(Mid(here, 3), "\", "/")

' the setup program records which Ubuntu it installed; otherwise use the default one
target = ""
If fso.FileExists(here & "\windows\distro.txt") Then
    d = Trim(fso.OpenTextFile(here & "\windows\distro.txt").ReadAll)
    If Len(d) > 0 Then target = "-d " & d & " -u root "
End If

If fso.FileExists(here & "\.setup-done") Then
    style = 0          ' hidden
Else
    style = 1          ' first run: show what it is doing
End If

sh.Run "wsl.exe " & target & "-e bash -lc ""bash '" & linux & "/start.sh'""", style, False
