@echo off
rem Puts Cherry OS on the Desktop and in the Start menu, with its icon.
set "HERE=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s = New-Object -ComObject WScript.Shell;" ^
  "foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {" ^
  "  $l = $s.CreateShortcut((Join-Path $dir 'Cherry OS.lnk'));" ^
  "  $l.TargetPath = 'wscript.exe';" ^
  "  $l.Arguments = [char]34 + $env:HERE + 'Cherry OS.vbs' + [char]34;" ^
  "  $l.IconLocation = $env:HERE + 'cherry.ico';" ^
  "  $l.WorkingDirectory = $env:HERE;" ^
  "  $l.Description = 'Cherry OS';" ^
  "  $l.Save() }"
echo.
echo  Cherry OS is on your Desktop and in the Start menu.
echo  Double-click it to start. You can close this window.
echo.
pause
