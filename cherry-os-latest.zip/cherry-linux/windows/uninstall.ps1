# Removes Cherry OS: the shortcuts, the Apps & features entry and its folder.
# Ubuntu and WSL stay, because other programs may use them.
$app = Split-Path -Parent $PSScriptRoot
$a = Read-Host 'Remove Cherry OS from this PC? (Y/N)'
if ($a -notmatch '^[Yy]') { exit 0 }
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $dir 'Cherry OS.lnk')
}
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\CherryOS'
Set-Location $env:TEMP
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $app
Write-Host 'Cherry OS has been removed.'
Start-Sleep -Seconds 2
