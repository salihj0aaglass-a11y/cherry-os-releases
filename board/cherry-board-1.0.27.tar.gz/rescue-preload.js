const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('rescue', (cmd) => ipcRenderer.send('rescue:cmd', cmd));
