// Cherry Board — receiving files from a laptop.
// The board runs a small page on the school's own network. The teacher opens it in any browser, drops his files in,
// and they land in the board's Documents folder straight away. Nothing leaves the school network and no account is needed.
const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');

const PORT = 8099;
const MAX_BYTES = 500 * 1024 * 1024; // one file, 500 MB — enough for a long presentation or a lesson video
// what a teacher actually sends. Anything else is refused, so the board never collects programs it cannot use.
const OK_EXT = ['pdf', 'pptx', 'ppt', 'docx', 'doc', 'xlsx', 'xls', 'txt', 'md', 'csv', 'rtf',
  'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg', 'heic',
  'mp4', 'webm', 'mkv', 'mov', 'avi', 'mp3', 'wav', 'm4a', 'ogg', 'zip'];

// the board's address on the school network (the laptop needs to be on the same Wi-Fi)
function localIPs() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list || []) if (i.family === 'IPv4' && !i.internal) out.push(i.address);
  }
  return out;
}
// a file name sent from outside is never trusted: no folders, no hidden names, no surprises
function safeName(raw) {
  let n = path.basename(String(raw || '').replace(/[\\/]+/g, '_')).replace(/[\u0000-\u001f\u007f]/g, '').trim();
  n = n.replace(/^\.+/, '').slice(0, 120);
  if (!n) return null;
  const ext = (n.split('.').pop() || '').toLowerCase();
  if (!n.includes('.') || !OK_EXT.includes(ext)) return null;
  return n;
}
async function freeName(dir, name) {
  const ext = path.extname(name), base = name.slice(0, name.length - ext.length);
  let out = name;
  for (let i = 2; i < 500 && fs.existsSync(path.join(dir, out)); i++) out = `${base} (${i})${ext}`;
  return out;
}

function page(pin) {
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>إرسال ملفات إلى السبورة</title><style>
*{box-sizing:border-box}body{margin:0;font-family:system-ui,"Segoe UI",Tahoma,sans-serif;background:#f6f3ff;color:#12112e;padding:20px}
.wrap{max-width:760px;margin:0 auto}h1{font-size:26px;margin:10px 0 4px}.sub{color:#6b6b8a;font-size:15px;margin-bottom:18px}
.drop{border:3px dashed #cfc6ff;border-radius:22px;background:#fff;padding:46px 20px;text-align:center;cursor:pointer;transition:.15s}
.drop.on{border-color:#cc0000;background:#fff5f5}.drop b{display:block;font-size:21px;margin-bottom:6px}.drop span{color:#6b6b8a;font-size:15px}
input[type=file]{display:none}
.row{display:flex;align-items:center;gap:12px;background:#fff;border-radius:16px;padding:12px 16px;margin-top:10px}
.row .nm{flex:1;min-width:0}.row .nm .t{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600}
.bar{height:8px;background:#eee;border-radius:4px;overflow:hidden;margin-top:6px}.bar i{display:block;height:100%;width:0;background:#cc0000;transition:width .2s}
.ok{color:#2e7d32;font-weight:700}.bad{color:#cc0000;font-weight:700}
button{border:0;border-radius:14px;padding:10px 18px;font-size:15px;font-family:inherit;cursor:pointer;background:#cc0000;color:#fff;font-weight:700}
button.g{background:#eee;color:#12112e}
.pin{display:flex;gap:10px;align-items:center;background:#fff;border-radius:16px;padding:16px;margin-bottom:16px}
.pin input{flex:1;font-size:22px;padding:10px;border:2px solid #ddd;border-radius:12px;text-align:center;letter-spacing:6px;font-family:inherit}
.hide{display:none}
</style></head><body><div class="wrap">
<h1>إرسال ملفات إلى السبورة 🍒</h1>
<div class="sub">اسحب ملفاتك هنا وستظهر على السبورة مباشرة. اللاب توب والسبورة على نفس الشبكة.</div>
<div class="pin" id="pinbox"><div>رمز السبورة:</div><input id="pin" inputmode="numeric" maxlength="4" placeholder="····"><button onclick="savePin()">دخول</button></div>
<div id="main" class="hide">
<div class="drop" id="drop"><b>اسحب الملفات هنا</b><span>أو اضغط للاختيار — عروض، ملفات Word، PDF، صور، فيديو</span></div>
<input type="file" id="f" multiple>
<div id="list"></div></div>
<script>
const $=(s)=>document.querySelector(s);let PIN=localStorage.getItem('cherryPin')||'';
function savePin(){PIN=$('#pin').value.trim();localStorage.setItem('cherryPin',PIN);check()}
async function check(){
  const r=await fetch('/ping',{headers:{'x-pin':PIN}});
  if(r.ok){$('#pinbox').classList.add('hide');$('#main').classList.remove('hide')}
  else{$('#pinbox').classList.remove('hide');$('#main').classList.add('hide');if(PIN)$('#pin').value=''}
}
check();
const drop=$('#drop'),f=$('#f');
drop.onclick=()=>f.click();
f.onchange=()=>{send([...f.files]);f.value=''};
['dragenter','dragover'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.add('on')}));
['dragleave','drop'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.remove('on')}));
drop.addEventListener('drop',ev=>send([...ev.dataTransfer.files]));
function send(files){for(const file of files)one(file)}
function one(file){
  const row=document.createElement('div');row.className='row';
  row.innerHTML='<div class="nm"><span class="t"></span><div class="bar"><i></i></div></div><div class="st"></div>';
  row.querySelector('.t').textContent=file.name;
  $('#list').prepend(row);
  const st=row.querySelector('.st'),fill=row.querySelector('.bar i');
  const x=new XMLHttpRequest();x.open('POST','/up');
  x.setRequestHeader('x-name',encodeURIComponent(file.name));x.setRequestHeader('x-pin',PIN);
  x.upload.onprogress=(e)=>{if(e.lengthComputable)fill.style.width=Math.round(e.loaded/e.total*100)+'%'};
  x.onload=()=>{
    let d={};try{d=JSON.parse(x.responseText)}catch(e){}
    if(x.status===200&&d.ok){row.querySelector('.bar').style.display='none';st.innerHTML='';
      const b=document.createElement('button');b.textContent='افتح على السبورة';
      b.onclick=()=>{fetch('/open',{method:'POST',headers:{'content-type':'application/json','x-pin':PIN},body:JSON.stringify({name:d.name})});b.textContent='فُتحت ✓';b.className='g'};
      const okl=document.createElement('span');okl.className='ok';okl.textContent='وصلت ✓ ';
      st.append(okl,b);}
    else{row.querySelector('.bar').style.display='none';st.className='bad';st.textContent=d.error||'لم تصل'}
  };
  x.onerror=()=>{row.querySelector('.bar').style.display='none';st.className='bad';st.textContent='انقطع الاتصال'};
  x.send(file);
}
</script></div></body></html>`;
}

// starts the page. onFile(fullPath, name) is called for every file that arrives, onOpen(fullPath) when the teacher
// presses "open on the board" from his laptop.
function startShare({ dir, pin, onFile, onOpen, log }) {
  const say = log || (() => {});
  const auth = (req) => String(req.headers['x-pin'] || '') === String(pin);
  const json = (res, code, obj) => { res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(obj)); };

  const server = http.createServer(async (req, res) => {
    res.setHeader('cache-control', 'no-store');
    try {
      const url = (req.url || '/').split('?')[0];
      if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); return res.end(page(pin));
      }
      if (url === '/ping') return auth(req) ? json(res, 200, { ok: true }) : json(res, 401, { ok: false });
      if (req.method === 'POST' && url === '/up') {
        if (!auth(req)) return json(res, 401, { ok: false, error: 'رمز خاطئ' });
        const name = safeName(decodeURIComponent(String(req.headers['x-name'] || '')));
        if (!name) return json(res, 400, { ok: false, error: 'نوع الملف غير مسموح' });
        await fsp.mkdir(dir, { recursive: true });
        const final = await freeName(dir, name);
        const tmp = path.join(dir, '.part-' + Date.now());
        const out = fs.createWriteStream(tmp);
        let bytes = 0, stop = false;
        req.on('data', (c) => {
          bytes += c.length;
          if (bytes > MAX_BYTES && !stop) { stop = true; out.destroy(); req.destroy(); fs.unlink(tmp, () => {}); json(res, 413, { ok: false, error: 'الملف كبير جداً (الحد ٥٠٠ ميجا)' }); }
        });
        req.pipe(out);
        out.on('close', async () => {
          if (stop) return;
          try {
            await fsp.rename(tmp, path.join(dir, final));
            say('received ' + final + ' (' + Math.round(bytes / 1024) + ' KB)');
            if (onFile) onFile(path.join(dir, final), final);
            json(res, 200, { ok: true, name: final });
          } catch (e) { fs.unlink(tmp, () => {}); json(res, 500, { ok: false, error: 'تعذر الحفظ' }); }
        });
        req.on('error', () => { out.destroy(); fs.unlink(tmp, () => {}); });
        return;
      }
      if (req.method === 'POST' && url === '/open') {
        if (!auth(req)) return json(res, 401, { ok: false });
        let body = '';
        req.on('data', (c) => { body += c; if (body.length > 4096) req.destroy(); });
        req.on('end', () => {
          let name = '';
          try { name = safeName(JSON.parse(body).name); } catch (e) { name = ''; }
          if (!name) return json(res, 400, { ok: false });
          const full = path.join(dir, name);
          if (!fs.existsSync(full)) return json(res, 404, { ok: false });
          if (onOpen) onOpen(full, name);
          json(res, 200, { ok: true });
        });
        return;
      }
      res.writeHead(404); res.end('not found');
    } catch (e) { say('error ' + e.message); try { res.writeHead(500); res.end(); } catch (e2) {} }
  });
  server.on('error', (e) => say('server error ' + e.message));
  server.listen(PORT, '0.0.0.0', () => say('sharing on port ' + PORT));
  return { server, port: PORT, stop: () => { try { server.close(); } catch (e) {} } };
}

module.exports = { startShare, localIPs, PORT, OK_EXT };
