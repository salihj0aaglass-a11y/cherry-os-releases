#!/bin/bash
# Cherry Board — installs the board onto the computer's own disk, next to Windows.
#
# It never touches an existing partition. It only uses empty (unallocated) space that someone already freed from
# inside Windows, writes Cherry Board there, and adds a boot menu where Cherry Board comes first and Windows second.
#
#   install-disk.sh check     → prints what it found, changes nothing
#   install-disk.sh install   → does the install
#
# Progress is printed as  STEP:<percent>:<message in Arabic>  so the board can show a bar.
set -o pipefail
MIN_GIB=12
say() { echo "STEP:$1:$2"; }
fail() { echo "ERR:$1"; exit 1; }

# ---------- find the disk we booted from, so we never install onto the USB stick ----------
live_src=$(findmnt -n -o SOURCE /cdrom 2>/dev/null | head -1)
live_disk=""
[ -n "$live_src" ] && live_disk=$(lsblk -no PKNAME "$live_src" 2>/dev/null | head -1)

# ---------- pick the internal disk: fixed (not removable), not the USB we booted from ----------
pick_disk() {
  local best="" bestsz=0
  for d in /sys/block/*; do
    local n=${d##*/}
    case "$n" in loop*|ram*|sr*|zram*|dm-*|md*) continue;; esac
    [ "$n" = "$live_disk" ] && continue
    [ "$(cat $d/removable 2>/dev/null)" = "1" ] && continue
    # a USB-attached disk is not the internal one
    readlink -f "$d" | grep -q '/usb[0-9]' && continue
    local sz=$(cat $d/size 2>/dev/null || echo 0)
    if [ "$sz" -gt "$bestsz" ]; then bestsz=$sz; best=$n; fi
  done
  echo "$best"
}
DISK_NAME=$(pick_disk)
[ -n "$DISK_NAME" ] || fail "لم يتم العثور على قرص داخلي في هذا الجهاز"
DISK=/dev/$DISK_NAME
part_of() { # partition device for disk $1 number $2 (handles sda1 and nvme0n1p1)
  case "$1" in *[0-9]) echo "$1p$2";; *) echo "$1$2";; esac
}

# ---------- the disk must use GPT + UEFI, like every Windows smartboard ----------
[ -d /sys/firmware/efi ] || fail "هذا الجهاز لا يقلع بنظام UEFI، والتثبيت بجانب ويندوز يحتاج UEFI"
sfdisk -d "$DISK" 2>/dev/null | grep -q 'label: gpt' || fail "قرص هذا الجهاز ليس من نوع GPT"

# ---------- find the EFI partition (where Windows keeps its boot files) ----------
ESP=""
for p in $(lsblk -lno NAME "$DISK" | tail -n +2); do
  t=$(blkid -s TYPE -o value "/dev/$p" 2>/dev/null)
  [ "$t" = "vfat" ] || continue
  pt=$(lsblk -no PARTTYPE "/dev/$p" 2>/dev/null)
  [ "$pt" = "c12a7328-f81f-11d2-ba4b-00a0c93ec93b" ] && { ESP="/dev/$p"; break; }
done
[ -n "$ESP" ] || fail "لم يتم العثور على قسم EFI على القرص الداخلي"

# ---------- is Windows there, and is the disk locked with BitLocker? ----------
WINDOWS="no"
mkdir -p /tmp/espchk
if mount -o ro "$ESP" /tmp/espchk 2>/dev/null; then
  [ -f /tmp/espchk/EFI/Microsoft/Boot/bootmgfw.efi ] && WINDOWS="yes"
  umount /tmp/espchk 2>/dev/null
fi
BITLOCKER="no"
for p in $(lsblk -lno NAME "$DISK" | tail -n +2); do
  # a BitLocker volume starts with the marker -FVE-FS- at offset 3
  if dd if="/dev/$p" bs=1 skip=3 count=8 2>/dev/null | grep -q -- '-FVE-FS-'; then BITLOCKER="yes"; fi
done

# ---------- the largest empty space on the disk ----------
read FREE_START FREE_SECTORS < <(sfdisk -F "$DISK" 2>/dev/null | awk '
  /^ *[0-9]+ +[0-9]+ +[0-9]+/ { if ($3+0 > best) { best=$3+0; s=$1+0 } }
  END { if (best) print s, best }')
FREE_GIB=0
[ -n "$FREE_SECTORS" ] && FREE_GIB=$(( FREE_SECTORS / 2 / 1024 / 1024 ))

# an existing Cherry Board install: an ext4 partition labelled cherry-root on the internal disk, and nothing else
CHERRY_PART=""; CHERRY_GIB=0
for p in $(lsblk -lno NAME "$DISK" | tail -n +2); do
  [ "$(blkid -s TYPE -o value "/dev/$p" 2>/dev/null)" = "ext4" ] || continue
  [ "$(blkid -s LABEL -o value "/dev/$p" 2>/dev/null)" = "cherry-root" ] || continue
  CHERRY_PART="/dev/$p"
  CHERRY_GIB=$(( $(cat /sys/class/block/$p/size) / 2 / 1024 / 1024 ))
done

if [ "$1" = "check" ]; then
  echo "cherry_part=$CHERRY_PART"
  echo "cherry_gib=$CHERRY_GIB"
  echo "disk=$DISK"
  echo "disk_size_gib=$(( $(cat /sys/block/$DISK_NAME/size) / 2 / 1024 / 1024 ))"
  echo "model=$(cat /sys/block/$DISK_NAME/device/model 2>/dev/null | tr -d '\n' | sed 's/ *$//')"
  echo "esp=$ESP"
  echo "windows=$WINDOWS"
  echo "bitlocker=$BITLOCKER"
  echo "free_gib=$FREE_GIB"
  echo "min_gib=$MIN_GIB"
  echo "live_disk=$live_disk"
  echo "ok=$([ "$FREE_GIB" -ge "$MIN_GIB" ] && [ "$BITLOCKER" = "no" ] && echo yes || echo no)"
  exit 0
fi
# ---------- removing it again: put the computer back to Windows only ----------
# Only the Cherry Board partition is deleted. Windows, its recovery partition and the EFI partition are left alone.
if [ "$1" = "remove" ]; then
  [ -n "$live_disk" ] || fail "شغّل السبورة من الفلاشة أولاً لإزالة التثبيت"
  [ -n "$CHERRY_PART" ] || fail "لا يوجد تثبيت للسبورة على هذا الجهاز"
  RP=${CHERRY_PART##*[!0-9]}
  # make sure we are deleting our own partition and nothing else
  [ "$(blkid -s LABEL -o value "$CHERRY_PART")" = "cherry-root" ] || fail "القسم غير مطابق — لم يتم حذف أي شيء"
  [ "$(findmnt -n -o SOURCE / 2>/dev/null)" != "$CHERRY_PART" ] || fail "لا يمكن حذف القسم الذي يعمل النظام منه"
  say 10 "تنظيف ملفات الإقلاع…"
  mkdir -p /espmnt
  if mount "$ESP" /espmnt 2>/dev/null; then
    # if Cherry Board replaced the computer's spare bootloader, put the old one back
    if [ -f /espmnt/EFI/BOOT/BOOTX64.EFI.cherry-backup ]; then
      mv -f /espmnt/EFI/BOOT/BOOTX64.EFI.cherry-backup /espmnt/EFI/BOOT/BOOTX64.EFI
    fi
    # only remove the spare-bootloader folder if Cherry Board created it in the first place
    if [ -f /espmnt/EFI/BOOT/cherry-created ]; then rm -rf /espmnt/EFI/BOOT; fi
    rm -rf /espmnt/EFI/ubuntu /espmnt/EFI/cherry
    sync; umount /espmnt
  fi
  say 40 "إزالة السبورة من قائمة الإقلاع…"
  if command -v efibootmgr >/dev/null 2>&1; then
    for n in $(efibootmgr 2>/dev/null | awk '/Cherry Board|[Bb]oot[0-9A-Fa-f]{4}\*? +ubuntu$/ {sub("\\*","",$1); sub("Boot","",$1); print $1}'); do
      efibootmgr -b "$n" -B >/dev/null 2>&1
    done
    # bring Windows back to the front
    WN=$(efibootmgr 2>/dev/null | awk '/Windows Boot Manager/ {sub("\\*","",$1); sub("Boot","",$1); print $1; exit}')
    if [ -n "$WN" ]; then
      ORDER=$(efibootmgr 2>/dev/null | awk -F': ' '/BootOrder/ {print $2}')
      REST=$(echo "$ORDER" | tr ',' '\n' | grep -v "^$WN$" | grep -v '^$' | paste -sd,)
      efibootmgr -o "$WN${REST:+,$REST}" >/dev/null 2>&1
    fi
  fi
  say 70 "حذف قسم السبورة…"
  sfdisk --delete "$DISK" "$RP" || fail "تعذر حذف القسم"
  partprobe "$DISK" 2>/dev/null; udevadm settle 2>/dev/null
  say 100 "تمت الإزالة"
  echo "DONE"
  exit 0
fi
[ "$1" = "install" ] || fail "استخدام غير صحيح"

# ---------- safety checks before writing anything ----------
[ "$BITLOCKER" = "no" ] || fail "القرص محمي بـ BitLocker — أوقف BitLocker من ويندوز أولاً"
[ "$FREE_GIB" -ge "$MIN_GIB" ] || fail "المساحة الفارغة $FREE_GIB جيجا فقط، والمطلوب $MIN_GIB جيجا على الأقل"
[ -n "$live_disk" ] || fail "لم يتم التعرف على فلاشة الإقلاع"
[ "/dev/$live_disk" != "$DISK" ] || fail "لا يمكن التثبيت على نفس الفلاشة"

say 3 "تجهيز مساحة للنظام…"
# align the start to 1 MiB and never run past the end of the free space
START=$(( (FREE_START + 2047) / 2048 * 2048 ))
SIZE=$(( FREE_SECTORS - (START - FREE_START) ))
[ "$SIZE" -gt 0 ] || fail "المساحة الفارغة غير صالحة"
BEFORE=$(lsblk -lno NAME "$DISK" | tail -n +2 | wc -l)
echo "start=$START, size=$SIZE, type=linux" | sfdisk --append --no-reread -q "$DISK" || fail "تعذر إنشاء القسم"
partprobe "$DISK" 2>/dev/null; udevadm settle 2>/dev/null; sleep 2

# the new partition is the one that appeared
NEWP=""
for p in $(lsblk -lno NAME "$DISK" | tail -n +2); do
  st=$(cat /sys/class/block/$p/start 2>/dev/null)
  [ "$st" = "$START" ] && NEWP="/dev/$p"
done
[ -n "$NEWP" ] || fail "تعذر العثور على القسم الجديد"
AFTER=$(lsblk -lno NAME "$DISK" | tail -n +2 | wc -l)
[ "$AFTER" -eq "$((BEFORE + 1))" ] || fail "تغيّر عدد الأقسام بشكل غير متوقع"

say 8 "تهيئة القسم…"
mkfs.ext4 -q -F -L cherry-root "$NEWP" || fail "تعذر تهيئة القسم"
T=/target
mkdir -p $T
mount "$NEWP" $T || fail "تعذر تركيب القسم الجديد"

say 12 "نسخ نظام السبورة… قد يستغرق عدة دقائق"
# --one-file-system keeps this to the live system only: /cdrom, /rofs, /proc, /sys, /dev and the USB stay out
( tar -C / --one-file-system --exclude=./tmp/'*' --exclude=./var/tmp/'*' --exclude=./target -cpf - . \
  | tar -C $T -xpf - ) &
TARPID=$!
# the bar follows how much has landed on the new partition
TOTAL_KB=$(df -k --output=used / | tail -1)
while kill -0 $TARPID 2>/dev/null; do
  USED=$(df -k --output=used $T | tail -1)
  PCT=$(( 12 + (USED * 60 / (TOTAL_KB > 0 ? TOTAL_KB : 1)) ))
  [ "$PCT" -gt 72 ] && PCT=72
  say $PCT "نسخ نظام السبورة… قد يستغرق عدة دقائق"
  sleep 4
done
wait $TARPID || fail "تعذر نسخ النظام"

say 74 "تجهيز نواة النظام…"
# The USB keeps the kernel outside the system image to stay small, so it is put back in place here.
# Without this the new system has no kernel and the computer would have nothing to start.
KV=$(uname -r)
mkdir -p $T/boot
[ -f /cdrom/casper/vmlinuz ] || fail "لم يتم العثور على نواة النظام على الفلاشة"
cp /cdrom/casper/vmlinuz "$T/boot/vmlinuz-$KV" || fail "تعذر نسخ النواة"
cp /cdrom/casper/initrd "$T/boot/initrd.img-$KV" || fail "تعذر نسخ ملف الإقلاع"
[ -f /boot/config-$KV ] && cp /boot/config-$KV $T/boot/ 2>/dev/null

say 75 "ضبط النظام…"
for d in dev dev/pts proc sys run; do mkdir -p $T/$d; done
mkdir -p $T/boot/efi $T/cdrom $T/rofs $T/media $T/mnt
ROOT_UUID=$(blkid -s UUID -o value "$NEWP")
ESP_UUID=$(blkid -s UUID -o value "$ESP")
cat > $T/etc/fstab <<EOF
# Cherry Board
UUID=$ROOT_UUID  /          ext4  errors=remount-ro  0 1
UUID=$ESP_UUID   /boot/efi  vfat  umask=0077         0 1
EOF
# the live system's leftovers are no longer needed once it lives on the disk
rm -f $T/etc/casper.conf
printf 'cherry-board\n' > $T/etc/hostname
# the board app needs these to manage Wi-Fi, flash drives, sound and power
printf 'cherry ALL=(ALL) NOPASSWD: ALL\n' > $T/etc/sudoers.d/cherry
chmod 440 $T/etc/sudoers.d/cherry

mount --rbind /dev $T/dev && mount -t proc proc $T/proc && mount --rbind /sys $T/sys && mount --bind /run $T/run
mount "$ESP" $T/boot/efi || fail "تعذر تركيب قسم EFI"
[ -d $T/sys/firmware/efi/efivars ] || echo "warn: efivars not visible in chroot"

say 80 "تجهيز الإقلاع…"
# the boot menu: Cherry Board first, Windows underneath it
cat > $T/etc/default/grub <<'EOF'
GRUB_DEFAULT=0
GRUB_TIMEOUT=3
GRUB_TIMEOUT_STYLE=menu
GRUB_DISTRIBUTOR="Cherry Board"
GRUB_CMDLINE_LINUX_DEFAULT="quiet splash vt.global_cursor_default=0"
GRUB_CMDLINE_LINUX=""
GRUB_DISABLE_OS_PROBER=true
GRUB_DISABLE_RECOVERY=true
EOF
if [ "$WINDOWS" = "yes" ]; then
cat > $T/etc/grub.d/40_custom <<EOF
#!/bin/sh
exec tail -n +3 \$0
menuentry "Windows" --class windows {
  insmod part_gpt
  insmod fat
  insmod chain
  search --no-floppy --fs-uuid --set=root $ESP_UUID
  chainloader /EFI/Microsoft/Boot/bootmgfw.efi
}
EOF
chmod +x $T/etc/grub.d/40_custom
fi

# the extra packages that ship with the board (sound driver, and efibootmgr which sets the boot order)
SYSFIX=$(dirname "$0")/sysfix
for d in "$SYSFIX"/*.deb; do [ -f "$d" ] && cp "$d" $T/tmp/ 2>/dev/null; done
chroot $T sh -c 'dpkg -i /tmp/*.deb >/dev/null 2>&1; rm -f /tmp/*.deb' 2>/dev/null

say 86 "تثبيت محمّل الإقلاع…"
# keep whatever was in the fallback slot, in case this computer relies on it
HAD_FALLBACK=yes
[ -d $T/boot/efi/EFI/BOOT ] || HAD_FALLBACK=no
if [ -f $T/boot/efi/EFI/BOOT/BOOTX64.EFI ] && [ ! -f $T/boot/efi/EFI/BOOT/BOOTX64.EFI.cherry-backup ]; then
  cp $T/boot/efi/EFI/BOOT/BOOTX64.EFI $T/boot/efi/EFI/BOOT/BOOTX64.EFI.cherry-backup
fi
# The Secure Boot version of GRUB has the path /EFI/ubuntu built into it and looks for its settings there,
# so the folder must keep that name. The boot entry the teacher sees is still named "Cherry Board".
rm -rf $T/boot/efi/EFI/cherry 2>/dev/null
chroot $T grub-install --target=x86_64-efi --efi-directory=/boot/efi --bootloader-id=ubuntu --recheck 2>&1 | tail -3
BOOTDIR=$T/boot/efi/EFI/ubuntu
[ -f $BOOTDIR/shimx64.efi ] && [ -f $BOOTDIR/grubx64.efi ] && [ -f $BOOTDIR/grub.cfg ] || fail "تعذر تثبيت محمّل الإقلاع"

# if this computer had no spare-bootloader folder before, mark ours so removing can clean it up completely
if [ "$HAD_FALLBACK" = "no" ] && [ -d $T/boot/efi/EFI/BOOT ]; then
  : > $T/boot/efi/EFI/BOOT/cherry-created
fi

say 90 "تحديث قائمة الإقلاع…"
chroot $T update-initramfs -u -k "$KV" >/dev/null 2>&1
chroot $T update-grub 2>&1 | tail -3
# never report success unless the menu really can start the board
grep -q "vmlinuz-$KV" $T/boot/grub/grub.cfg 2>/dev/null || fail "تعذر إنشاء قائمة الإقلاع"
if [ "$WINDOWS" = "yes" ]; then grep -qi 'menuentry "Windows"' $T/boot/grub/grub.cfg || echo "warn: Windows entry missing from the menu"; fi

say 95 "جعل السبورة أول خيار عند التشغيل…"
# The computer must know about Cherry Board and start it first. Windows keeps its own entry and stays in the list.
ESP_NUM=$(echo "$ESP" | grep -o '[0-9]*$')
entry_num() { chroot $T efibootmgr 2>/dev/null | awk '/Cherry Board/ {sub("\\*","",$1); sub("Boot","",$1); print $1; exit}'; }
NUM=$(entry_num)
if [ -z "$NUM" ]; then
  chroot $T efibootmgr -c -d "$DISK" -p "$ESP_NUM" -L "Cherry Board" -l '\EFI\ubuntu\shimx64.efi' >/dev/null 2>&1
  NUM=$(entry_num)
fi
# grub-install adds its own "ubuntu" entry; one clearly named entry is enough for the teacher
UB=$(chroot $T efibootmgr 2>/dev/null | awk '/^Boot[0-9A-Fa-f]{4}\*? +ubuntu$/ {sub("\\*","",$1); sub("Boot","",$1); print $1; exit}')
[ -n "$UB" ] && [ -n "$NUM" ] && chroot $T efibootmgr -b "$UB" -B >/dev/null 2>&1
if [ -n "$NUM" ]; then
  ORDER=$(chroot $T efibootmgr 2>/dev/null | awk -F': ' '/BootOrder/ {print $2}')
  REST=$(echo "$ORDER" | tr ',' '\n' | grep -v "^$NUM$" | grep -v '^$' | paste -sd,)
  chroot $T efibootmgr -o "$NUM${REST:+,$REST}" >/dev/null 2>&1
  echo "boot entry $NUM set first"
else
  # this computer will not let us change its boot list: leave a bootloader in the standard fallback slot instead
  echo "warn: could not register a boot entry; installing to the fallback path"
  chroot $T grub-install --target=x86_64-efi --efi-directory=/boot/efi --removable --recheck >/dev/null 2>&1
  echo "NOBOOTENTRY"
fi

say 98 "إنهاء…"
umount $T/boot/efi 2>/dev/null
umount -R $T/sys $T/dev 2>/dev/null
umount $T/run $T/proc 2>/dev/null
sync
umount $T 2>/dev/null
say 100 "تم التثبيت"
echo "DONE"
