#!/bin/bash
# clone-usb.sh — make another bootable Cherry Board stick from the one this board is running on.
#
# This does the whole job Rufus does on a Windows PC: it wipes the target stick, lays down a partition
# table, formats it, copies the system across and writes the boot code — so the new stick starts on its
# own on both UEFI and older BIOS machines. Nothing of the school's is carried over: the saved-work file
# and anything a teacher dropped on the stick are left behind, so the copy comes out as a fresh board.
#
#   list            which sticks could be written to
#   clone /dev/sdX  write one (ERASES it)
#
# Progress is printed as P:<percent> lines so the screen can show a bar.
set -u
# the system tools live in sbin, which is not always on PATH when this is run through sudo
export PATH="/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
say() { echo "$1"; }
fail() { echo "ERR:$1"; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "الأداة $1 غير موجودة على السبورة"; }

# The stick this board is running from, and the disk the system lives on. Neither may ever be written to.
SRC_PART=$(findmnt -n -o SOURCE /cdrom 2>/dev/null | head -1)
SRC_DISK=""
[ -n "$SRC_PART" ] && SRC_DISK="/dev/$(lsblk -no PKNAME "$SRC_PART" 2>/dev/null | head -1)"
ROOT_PART=$(findmnt -n -o SOURCE / 2>/dev/null | head -1)
ROOT_DISK=""
[ -n "$ROOT_PART" ] && ROOT_DISK="/dev/$(lsblk -no PKNAME "$ROOT_PART" 2>/dev/null | head -1)"

# Everything that has to land on the copy. The saved-work file is deliberately not in it.
SKIP="writable writable.tmp casper-rw home-rw lost+found System Volume Information"

usable_bytes() {
  local t=0 e b
  for e in /cdrom/* /cdrom/.disk; do
    [ -e "$e" ] || continue
    b=$(basename "$e")
    case " $SKIP " in *" $b "*) continue;; esac
    t=$((t + $(du -sb "$e" 2>/dev/null | cut -f1)))
  done
  echo "$t"
}

if [ "${1:-}" = "list" ]; then
  [ -n "$SRC_PART" ] || { echo "nosource=1"; exit 0; }
  echo "need=$(usable_bytes)"
  echo "source=$SRC_DISK"
  # only removable USB whole-disks, and never the one we booted from or the one the system is on
  while read -r name size model rm tran; do
    dev="/dev/$name"
    [ "$dev" = "$SRC_DISK" ] && continue
    [ -n "$ROOT_DISK" ] && [ "$dev" = "$ROOT_DISK" ] && continue
    [ "$rm" = "1" ] || [ "$tran" = "usb" ] || continue
    [ "$rm" = "1" ] || continue
    bytes=$(blockdev --getsize64 "$dev" 2>/dev/null || echo 0)
    echo "disk=$dev|$bytes|$size|${model:-فلاشة}"
  done < <(lsblk -dn -o NAME,SIZE,MODEL,RM,TRAN 2>/dev/null)
  exit 0
fi

[ "${1:-}" = "clone" ] || fail "استخدام: clone-usb.sh list | clone /dev/sdX"
DEV="${2:-}"
[ -n "$DEV" ] || fail "لم تُحدَّد الفلاشة"
[ -b "$DEV" ] || fail "$DEV ليس قرصاً"
[ -n "$SRC_PART" ] || fail "هذه السبورة لا تعمل من فلاشة، فلا يوجد ما يُنسخ"

# ---- the guards. A wrong device here would wipe the school's computer. ----
[ "$DEV" = "$SRC_DISK" ] && fail "هذه هي الفلاشة التي تعمل منها السبورة"
[ -n "$ROOT_DISK" ] && [ "$DEV" = "$ROOT_DISK" ] && fail "هذا هو قرص النظام"
BASE=$(basename "$DEV")
[ -e "/sys/block/$BASE" ] || fail "اختر الفلاشة كاملة، لا قسماً منها"
[ "$(cat "/sys/block/$BASE/removable" 2>/dev/null)" = "1" ] || fail "هذا ليس قرصاً قابلاً للإزالة — رُفض حفاظاً على بيانات الجهاز"
for p in $(lsblk -lno NAME "$DEV" 2>/dev/null | tail -n +2); do
  m=$(findmnt -n -o TARGET "/dev/$p" 2>/dev/null | head -1)
  case "$m" in /|/cdrom|/boot*|/home) fail "الفلاشة مستخدمة من النظام الآن";; esac
done

NEED=$(usable_bytes)
SIZE=$(blockdev --getsize64 "$DEV" 2>/dev/null || echo 0)
[ "$SIZE" -gt $((NEED + 300 * 1024 * 1024)) ] || fail "الفلاشة صغيرة — تحتاج على الأقل $(( (NEED + 300*1024*1024) / 1000000000 + 1 )) جيجا"
# FAT32 cannot hold a single file of 4 GB or more
BIG=$(find /cdrom -type f -size +4190M 2>/dev/null | head -1)
[ -z "$BIG" ] || fail "ملف النظام أكبر من ٤ جيجا ولا يمكن نسخه بهذه الطريقة"

need mkfs.vfat; need sfdisk
say "P:1"

# ---- unmount anything already open on it ----
for p in $(lsblk -lno NAME "$DEV" 2>/dev/null | tail -n +2); do umount -f "/dev/$p" 2>/dev/null; done
sleep 1

# ---- partition: one FAT32 partition in an MBR table, flagged bootable.
# MBR rather than GPT because it is the combination every firmware accepts: UEFI machines boot
# \EFI\BOOT\BOOTX64.EFI straight off a removable FAT32 partition, and older BIOS machines can boot
# the GRUB written below. This is the same layout Rufus writes by default. ----
say "P:3"
wipefs -a "$DEV" >/dev/null 2>&1
dd if=/dev/zero of="$DEV" bs=1M count=8 status=none 2>/dev/null
printf 'label: dos\n,,c,*\n' | sfdisk --quiet --force "$DEV" >/dev/null 2>&1 || fail "تعذّر تقسيم الفلاشة"
sync; sleep 1
partx -u "$DEV" >/dev/null 2>&1 || blockdev --rereadpt "$DEV" >/dev/null 2>&1
sleep 2

PART="${DEV}1"
[ -b "$PART" ] || PART="${DEV}p1"
[ -b "$PART" ] || fail "لم يظهر القسم الجديد على الفلاشة"

say "P:6"
mkfs.vfat -F 32 -n CHERRYBOARD "$PART" >/dev/null 2>&1 || fail "تعذّر تهيئة الفلاشة"
sync

MNT=$(mktemp -d)
mount "$PART" "$MNT" 2>/dev/null || fail "تعذّر فتح الفلاشة بعد التهيئة"
cleanup() { cd /; umount "$MNT" 2>/dev/null; rmdir "$MNT" 2>/dev/null; }
trap cleanup EXIT

# ---- copy the system over, skipping everything that belongs to this school ----
say "P:8"
(
  for e in /cdrom/* /cdrom/.disk; do
    [ -e "$e" ] || continue
    b=$(basename "$e")
    case " $SKIP " in *" $b "*) continue;; esac
    cp -r --no-preserve=all "$e" "$MNT"/ 2>/dev/null
  done
  touch "$MNT/.copy-done"
) &
COPY=$!
while kill -0 "$COPY" 2>/dev/null; do
  NOW=$(du -sb "$MNT" 2>/dev/null | cut -f1)
  [ -n "$NOW" ] && [ "$NEED" -gt 0 ] && say "P:$(( 8 + NOW * 80 / NEED ))"
  sleep 2
done
wait "$COPY"
[ -f "$MNT/.copy-done" ] || fail "توقّف النسخ قبل أن يكتمل"
rm -f "$MNT/.copy-done"

# ---- check the copy can actually start before calling it done ----
say "P:90"
[ -f "$MNT/EFI/BOOT/BOOTX64.EFI" ] || fail "ملف الإقلاع لم يُنسخ"
[ -f "$MNT/.disk/cherry-board" ] || fail "علامة القرص لم تُنسخ"
[ -f "$MNT/casper/vmlinuz" ] || fail "نواة النظام لم تُنسخ"
[ -f "$MNT/casper/filesystem.squashfs" ] || fail "ملف النظام لم يُنسخ"

# ---- boot code for older BIOS machines. UEFI already works from the file above, so if this
# part is not available the stick is still good on anything modern; we only note it. ----
say "P:93"
BIOS=no
if command -v grub-install >/dev/null 2>&1 && [ -d /usr/lib/grub/i386-pc ]; then
  grub-install --target=i386-pc --boot-directory="$MNT/boot" --no-floppy --recheck "$DEV" >/dev/null 2>&1 && BIOS=yes
fi

say "P:96"
sync
umount "$MNT" 2>/dev/null
trap - EXIT
rmdir "$MNT" 2>/dev/null
sync
say "P:100"
echo "bios=$BIOS"
echo "DONE"
