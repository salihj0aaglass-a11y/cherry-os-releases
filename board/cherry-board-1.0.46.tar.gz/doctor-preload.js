const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('doctor', {
  why: () => ipcRenderer.invoke('doctor:why'),
  run: () => ipcRenderer.invoke('doctor:run'),
  onStep: (fn) => ipcRenderer.on('doctor-step', (_e, s) => fn(s)),
  report: () => ipcRenderer.invoke('doctor:report'),
  act: (what) => ipcRenderer.send('doctor:do', what),
});
