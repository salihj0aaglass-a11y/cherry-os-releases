#!/bin/bash
# Cherry Board — keeps the computer from freezing. Run once at start (as root).
#
# 1) A live stick has no swap. When the memory fills up (YouTube, big PDFs, many apps), Linux then grinds
#    almost to a stop instead of closing something, and the teacher has to switch the whole board off.
#    So we give it compressed swap kept in RAM (zram): it holds roughly twice its size and keeps things moving.
# 2) Writes to a USB stick are slow. By default Linux lets hundreds of MB pile up and then everything waits
#    for the stick at once. Small limits make it write a little at a time instead.
if ! swapon --noheadings 2>/dev/null | grep -q .; then
  modprobe zram 2>/dev/null
  total=$(awk '/MemTotal/ {print $2}' /proc/meminfo)            # kB
  size=$(( total * 1024 / 2 ))                                     # half the RAM, compressed
  dev=$(zramctl -f -s "$size" -a zstd 2>/dev/null || zramctl -f -s "$size" -a lz4 2>/dev/null || zramctl -f -s "$size" 2>/dev/null)
  if [ -n "$dev" ] && mkswap "$dev" >/dev/null 2>&1 && swapon -p 100 "$dev" 2>/dev/null; then echo "zram=$dev size=$((size / 1048576))MB"; else echo "zram=failed"; fi
else
  echo "swap=already"
fi
sysctl -q -w vm.swappiness=100 vm.page-cluster=0 vm.dirty_bytes=67108864 vm.dirty_background_bytes=16777216 2>/dev/null && echo "writes=small"
echo "DONE"
