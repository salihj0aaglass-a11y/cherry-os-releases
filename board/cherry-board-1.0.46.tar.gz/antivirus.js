// Cherry Board — the antivirus (ClamAV), installed from Settings.
// The board itself runs Linux, which Windows viruses cannot infect, but the flash drives teachers and
// students carry between school computers often bring Windows viruses (the "shortcut virus", autorun
// worms, infected Office files) and pass them on. So the antivirus scans flash drives and the board's files,
// and can scan each flash drive by itself as soon as it is plugged in.
// ClamAV is free and comes from Ubuntu: installing it needs the internet once; its virus list (~250 MB)
// then updates itself.
'use strict';
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { spawn } = require('child_process');

function createAntivirus(d) { // d: { run, DATA, send(event, data), log, loadSettings, saveSettings }
  const STATE_FILE = path.join(d.DATA, 'antivirus.json');
  let busy = null; // 'install' | 'update' | 'scan'
  let proc = null;
  let cancelled = false;
  const load = () => { try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch (e) { return {}; } };
  const save = (o) => { try { fs.writeFileSync(STATE_FILE, JSON.stringify({ ...load(), ...o })); } catch (e) {} };
  const tell = (o) => d.send('av', { busy, ...o });

  async function installed() { return (await d.run('which', ['clamscan'])).ok; }
  async function dbDate() {
    // the newest virus list file tells how fresh the protection is
    let newest = 0;
    for (const f of await fsp.readdir('/var/lib/clamav').catch(() => [])) {
      if (!/\.(cvd|cld|cud|hdb|hsb|ndb|ldb)$/.test(f)) continue;
      try { newest = Math.max(newest, (await fsp.stat(path.join('/var/lib/clamav', f))).mtimeMs); } catch (e) {}
    }
    return newest;
  }
  async function status() {
    const ok = await installed();
    const st = load();
    const mi = await fsp.readFile('/proc/meminfo', 'utf8').catch(() => '');
    const kb = (k) => +((mi.match(new RegExp('^' + k + ':\\s*(\\d+)', 'm')) || [])[1] || 0);
    return {
      installed: ok, busy, db: ok ? await dbDate() : 0, version: ok ? (await d.run('clamscan', ['--version'])).out.trim() : '',
      auto: !!d.loadSettings().avAuto, last: st.last || null, ramGB: Math.round(kb('MemTotal') / 104857.6) / 10,
    };
  }

  // a long command whose lines are shown to the teacher as it goes
  function stream(cmd, args, onLine, timeoutMs) {
    return new Promise((resolve) => {
      let out = '', buf = '';
      const p = spawn(cmd, args, { env: { ...process.env, DEBIAN_FRONTEND: 'noninteractive', LANG: 'C' } });
      proc = p;
      const timer = timeoutMs ? setTimeout(() => { try { p.kill('SIGTERM'); } catch (e) {} }, timeoutMs) : null;
      const feed = (chunk) => {
        buf += chunk.toString();
        const lines = buf.split('\n'); buf = lines.pop();
        for (const l of lines) { out += l + '\n'; if (out.length > 400000) out = out.slice(-200000); try { onLine(l); } catch (e) {} }
      };
      p.stdout.on('data', feed); p.stderr.on('data', feed);
      p.on('close', (code) => { if (timer) clearTimeout(timer); if (buf) { out += buf; try { onLine(buf); } catch (e) {} } proc = null; resolve({ code, out }); });
      p.on('error', () => { if (timer) clearTimeout(timer); proc = null; resolve({ code: -1, out }); });
    });
  }

  async function install() {
    if (busy) return { ok: false, error: 'العملية السابقة لم تنتهِ بعد' };
    if (await installed()) return { ok: true };
    busy = 'install'; cancelled = false;
    try {
      const free = await fsp.statfs('/var').then((s) => s.bavail * s.bsize).catch(() => Infinity);
      if (free < 700 * 1048576) return { ok: false, error: 'المساحة غير كافية — يحتاج مكافح الفيروسات حوالي ٧٠٠ ميغابايت. فعّل «حفظ التغييرات» على فلاشة أكبر.' };
      tell({ step: 'تحديث قائمة البرامج…', pct: 5 });
      const u = await stream('sudo', ['-n', 'apt-get', 'update', '-q'], () => {}, 300000);
      if (u.code !== 0 && /Could not resolve|Temporary failure|Failed to fetch/i.test(u.out)) return { ok: false, error: 'لا يوجد اتصال بالإنترنت — اتصل بالواي فاي ثم حاول مرة أخرى' };
      tell({ step: 'تنزيل مكافح الفيروسات وتثبيته…', pct: 20 });
      let n = 0;
      const r = await stream('sudo', ['-n', 'env', 'DEBIAN_FRONTEND=noninteractive', 'apt-get', 'install', '-y', '-q', '--no-install-recommends', 'clamav', 'clamav-freshclam'],
        (l) => { if (/^(Get|Unpacking|Setting up)/.test(l)) tell({ step: 'تنزيل مكافح الفيروسات وتثبيته…', pct: Math.min(60, 20 + ++n) }); }, 900000);
      if (!(await installed())) { d.log('antivirus install failed: ' + r.out.slice(-600)); return { ok: false, error: 'تعذّر التثبيت — تأكد من الإنترنت وحاول مرة أخرى' }; }
      d.log('antivirus installed');
      const up = await update(true);
      return up.ok ? { ok: true } : { ok: true, warn: up.error };
    } finally { busy = null; tell({ done: true }); }
  }

  // the virus list: the freshclam service keeps it fresh by itself; this fetches it now
  async function update(inner) {
    if (busy && !inner) return { ok: false, error: 'العملية السابقة لم تنتهِ بعد' };
    if (!inner) busy = 'update';
    try {
      tell({ step: 'تنزيل قائمة الفيروسات (حوالي ٢٥٠ ميغابايت أول مرة)…', pct: 65 });
      await d.run('sudo', ['-n', 'systemctl', 'stop', 'clamav-freshclam'], { timeout: 30000 });
      const r = await stream('sudo', ['-n', 'freshclam', '--stdout'], (l) => {
        const m = l.match(/(\d+)%/); if (m) tell({ step: 'تنزيل قائمة الفيروسات…', pct: 65 + Math.round(+m[1] * 0.33) });
      }, 1800000);
      await d.run('sudo', ['-n', 'systemctl', 'enable', '--now', 'clamav-freshclam'], { timeout: 30000 });
      const ok = (await dbDate()) > 0;
      if (!ok) d.log('freshclam failed: ' + r.out.slice(-600));
      return ok ? { ok: true } : { ok: false, error: /Can't connect|resolve|timed out/i.test(r.out) ? 'لا يوجد اتصال بالإنترنت لتنزيل قائمة الفيروسات' : 'تعذّر تنزيل قائمة الفيروسات — حاول لاحقاً' };
    } finally { if (!inner) { busy = null; tell({ done: true }); } }
  }

  // scan folders (flash drives, the board's files); infected files are listed, nothing is deleted without asking
  async function scan(targets, why) {
    if (busy) return { ok: false, error: 'فحص آخر يعمل الآن' };
    if (!(await installed())) return { ok: false, error: 'مكافح الفيروسات غير مثبّت' };
    if (!(await dbDate())) return { ok: false, error: 'قائمة الفيروسات لم تُنزّل بعد — اضغط «تحديث قائمة الفيروسات»' };
    targets = (targets || []).filter((t) => t && fs.existsSync(t));
    if (!targets.length) return { ok: false, error: 'لا يوجد ما يُفحص — وصّل فلاشة' };
    // the virus list takes about 1 GB of memory while scanning; on a small board, close other apps first
    const mi = await fsp.readFile('/proc/meminfo', 'utf8').catch(() => '');
    const kb = (k) => +((mi.match(new RegExp('^' + k + ':\\s*(\\d+)', 'm')) || [])[1] || 0);
    if (kb('MemAvailable') + kb('SwapFree') * 0.5 < 1100 * 1024) return { ok: false, error: 'الذاكرة لا تكفي للفحص الآن — أغلق يوتيوب والتطبيقات المفتوحة ثم حاول مرة أخرى' };
    busy = 'scan'; cancelled = false;
    const t0 = Date.now();
    const found = [];
    let files = 0, lastTell = 0;
    tell({ step: 'تحميل قائمة الفيروسات…', files: 0, found: [] });
    try {
      // nice + ionice: the board stays usable while it scans
      const r = await stream('nice', ['-n', '15', 'ionice', '-c3', 'clamscan', '-r', '-v', '--stdout', '--max-filesize=200M', '--max-scansize=400M', ...targets], (l) => {
        if (l.startsWith('Scanning ')) {
          files++;
          if (Date.now() - lastTell > 400) { lastTell = Date.now(); tell({ step: 'يفحص…', files, current: path.basename(l.slice(9)), found }); }
        } else {
          const m = l.match(/^(.*): (.+) FOUND$/);
          if (m) { found.push({ file: m[1], virus: m[2] }); tell({ step: 'يفحص…', files, found }); }
        }
      }, 3 * 3600000);
      const sum = r.out.match(/Scanned files: (\d+)/);
      if (sum) files = +sum[1];
      const result = { when: Date.now(), secs: Math.round((Date.now() - t0) / 1000), files, found, targets, why: why || '', stopped: cancelled };
      save({ last: result });
      d.log(`antivirus scan: ${files} files, ${found.length} infected${cancelled ? ' (stopped)' : ''}`);
      return { ok: true, ...result };
    } finally { busy = null; tell({ done: true }); }
  }
  function stop() { cancelled = true; if (proc) { try { proc.kill('SIGTERM'); } catch (e) {} } return { ok: true }; }

  // infected files: delete them (the teacher pressed the button)
  async function remove(files) {
    let n = 0;
    for (const f of files || []) {
      try { await fsp.unlink(f); n++; } catch (e) {
        if ((await d.run('sudo', ['-n', 'rm', '-f', '--', f])).ok && !fs.existsSync(f)) n++;
      }
    }
    const st = load();
    if (st.last && st.last.found) { st.last.found = st.last.found.filter((x) => fs.existsSync(x.file)); save({ last: st.last }); }
    await d.run('sync', []);
    return { ok: true, removed: n };
  }

  function setAuto(on) { const s = d.loadSettings(); s.avAuto = !!on; d.saveSettings(s); return { ok: true }; }
  // a flash drive was just plugged in
  async function onDrive(mount, label) {
    if (!d.loadSettings().avAuto || busy || !(await installed()) || !(await dbDate())) return;
    d.send('av-auto', { mount, label, start: true });
    const r = await scan([mount], 'auto');
    d.send('av-auto', { mount, label, ...r });
  }
  return { status, install, update: () => update(false), scan, stop, remove, setAuto, onDrive };
}
module.exports = { createAntivirus };
