// Tapping the cherry or the loading bar on the start screen calls طبيب Cherry. This tiny file loads before
// everything else and needs nothing else, so it still works when the board's own files are what is broken.
(function () {
  var b = document.getElementById('boot'); if (!b) return;
  b.addEventListener('pointerdown', function (e) {
    if (!e.target.closest('.boot-cherry,.boot-bar,.boot-help')) return;
    if (window.cherry && window.cherry.doctor) window.cherry.doctor();
  });
})();
