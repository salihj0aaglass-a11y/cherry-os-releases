#!/usr/bin/env python3
# Cherry Board — steer the PowerPoint slideshow window (LibreOffice) with no window manager.
# Uses only libX11 + libXtst through ctypes, which every Cherry Board has.
#   slidectl.py find            -> prints the slideshow window id (exit 1 if none)
#   slidectl.py raise           -> put the slideshow on top and give it the keyboard
#   slidectl.py key Right|Left|Escape|Home|End
import ctypes, sys, time

X = ctypes.cdll.LoadLibrary('libX11.so.6')
T = ctypes.cdll.LoadLibrary('libXtst.so.6')
Window = ctypes.c_ulong
X.XOpenDisplay.restype = ctypes.c_void_p
X.XOpenDisplay.argtypes = [ctypes.c_char_p]
X.XDefaultRootWindow.restype = Window
X.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
X.XQueryTree.argtypes = [ctypes.c_void_p, Window, ctypes.POINTER(Window), ctypes.POINTER(Window), ctypes.POINTER(ctypes.POINTER(Window)), ctypes.POINTER(ctypes.c_uint)]
X.XFetchName.argtypes = [ctypes.c_void_p, Window, ctypes.POINTER(ctypes.c_char_p)]
X.XFree.argtypes = [ctypes.c_void_p]
X.XRaiseWindow.argtypes = [ctypes.c_void_p, Window]
X.XSetInputFocus.argtypes = [ctypes.c_void_p, Window, ctypes.c_int, ctypes.c_ulong]
X.XStringToKeysym.restype = ctypes.c_ulong
X.XStringToKeysym.argtypes = [ctypes.c_char_p]
X.XKeysymToKeycode.restype = ctypes.c_ubyte
X.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
X.XFlush.argtypes = [ctypes.c_void_p]
X.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]
T.XTestFakeKeyEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]

class XWindowAttributes(ctypes.Structure):
    _fields_ = [('x', ctypes.c_int), ('y', ctypes.c_int), ('width', ctypes.c_int), ('height', ctypes.c_int), ('border_width', ctypes.c_int),
                ('depth', ctypes.c_int), ('visual', ctypes.c_void_p), ('root', Window), ('c_class', ctypes.c_int), ('bit_gravity', ctypes.c_int),
                ('win_gravity', ctypes.c_int), ('backing_store', ctypes.c_int), ('backing_planes', ctypes.c_ulong), ('backing_pixel', ctypes.c_ulong),
                ('save_under', ctypes.c_int), ('colormap', ctypes.c_ulong), ('map_installed', ctypes.c_int), ('map_state', ctypes.c_int),
                ('all_event_masks', ctypes.c_long), ('your_event_mask', ctypes.c_long), ('do_not_propagate_mask', ctypes.c_long),
                ('override_redirect', ctypes.c_int), ('screen', ctypes.c_void_p)]
X.XGetWindowAttributes.argtypes = [ctypes.c_void_p, Window, ctypes.POINTER(XWindowAttributes)]

d = X.XOpenDisplay(None)
if not d:
    sys.exit(2)

def kids(w):
    r, p, ch, n = Window(), Window(), ctypes.POINTER(Window)(), ctypes.c_uint()
    if not X.XQueryTree(d, w, ctypes.byref(r), ctypes.byref(p), ctypes.byref(ch), ctypes.byref(n)):
        return []
    out = [ch[i] for i in range(n.value)]
    if ch:
        X.XFree(ch)
    return out

def name(w):
    s = ctypes.c_char_p()
    if X.XFetchName(d, w, ctypes.byref(s)) and s.value:
        v = s.value.decode('utf-8', 'replace')
        return v
    return ''

def viewable(w):
    a = XWindowAttributes()
    return X.XGetWindowAttributes(d, w, ctypes.byref(a)) and a.map_state == 2

def find():
    stack = [(X.XDefaultRootWindow(d), 0)]
    while stack:
        w, depth = stack.pop()
        n = name(w)
        if n.startswith('Presenting') and viewable(w):
            return w
        if depth < 3:
            stack.extend((c, depth + 1) for c in kids(w))
    return None

cmd = sys.argv[1] if len(sys.argv) > 1 else 'find'
w = find()
if not w:
    sys.exit(1)
if cmd == 'find':
    print(w)
elif cmd == 'raise':
    X.XRaiseWindow(d, w); X.XSetInputFocus(d, w, 2, 0); X.XSync(d, 0)
elif cmd == 'key':
    X.XSetInputFocus(d, w, 2, 0); X.XSync(d, 0)
    kc = X.XKeysymToKeycode(d, X.XStringToKeysym(sys.argv[2].encode()))
    T.XTestFakeKeyEvent(d, kc, 1, 0); X.XFlush(d); time.sleep(0.03)
    T.XTestFakeKeyEvent(d, kc, 0, 0); X.XSync(d, 0)
