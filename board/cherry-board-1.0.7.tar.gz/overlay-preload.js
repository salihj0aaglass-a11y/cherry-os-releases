const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('ctl', (cmd) => ipcRenderer.send('slideshow:cmd', cmd));
